l=[1,4,2,87,32,25,34,89,21]
maxV=l[0]
for i in range(0,len(l),1):
    if maxV < l[i]: maxV=l[i]
    
print(maxV)
