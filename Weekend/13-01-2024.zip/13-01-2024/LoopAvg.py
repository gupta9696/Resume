l=[1,4,2,3]
maxV=0
for i in range(0,len(l),1):
    maxV+=l[i]
#print(len(l)) 
print(maxV/len(l))
