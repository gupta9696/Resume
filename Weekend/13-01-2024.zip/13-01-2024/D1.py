name_string="Pavan, Ravi, Radhe, Umang"
#name = ["Pavan","Ravi"]
name = name_string.split(", ")
for i in range(0, len(name),1):print(name[i])
