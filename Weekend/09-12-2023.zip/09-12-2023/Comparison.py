v1=int(input("Eneter the first value"))
v2=int(input("Eneter the second value"))

print("Checking == ", v1 == v2)
print("Checking != ", v1 != v2)
print("Checking > ", v1 > v2)
print("Checking < ", v1 < v2)
print("Checking >= ", v1 >= v2)
print("Checking <= ", v1 <= v2)
