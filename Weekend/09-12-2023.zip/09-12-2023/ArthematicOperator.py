print("hello")
v1=input("Eneter the first value")
v1=int(v1)
print("Value of v1 ",v1)
v2=input("Eneter the second value")
v2=int(v2)
print("Value of v2 ",v2)

print("Addition ", v1+v2)
print("Sub ", v1-v2)
print("Mul ", v1*v2)
print("Div ", v1/v2)
print("Modulas ", v1%v2)
print("exponent ", v1**v2)
print("floor ", v1//v2)





