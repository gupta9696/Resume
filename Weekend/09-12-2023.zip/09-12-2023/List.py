obj=[5,6,98]
print(len(obj))
obj[1]=100
print(obj)
obj[0]=67
obj[2]=obj[1]
print(obj)
