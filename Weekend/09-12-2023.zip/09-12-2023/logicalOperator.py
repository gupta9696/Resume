v1=int(input("Eneter the first value"))
v2=int(input("Eneter the second value"))

print(v1&v2)
print(v1|v2)
print(v1^v2)

name ='PAvan'
print(name)
name ="PAvefewfn"
print(name)
name ='''PAvan 
'''
print(name)

