print("Hi")
amount=1000
msg='''      1 -> Credit
        2 -> Debit
        3 -> Check Balance
        4 -> Exit'''
while(True):
    choice=int(input(msg))
    if(choice == 1): 
        creditAmt=int(input("Enter Credit Amount "))
        amount=amount+creditAmt
        print("Available Bsalance : ",amount)
    elif(choice == 2):
        dAmt=int(input("Enter Debit Amount "))
        if(amount > 100):
            amount=amount-dAmt
        else:print("Your amount is less 100rs")
        print("Available Bsalance : ",amount)
    elif(choice == 3):print("Available Bsalance : ",amount)
    elif(choice == 4):exit()
    
    