v1=5
v2=7
#v2=5 and v1=7 without using third variable
#v3=v1
#v1=v2
#v2=v3
v1=v1+v2 #v1=12
v2=v1-v2 #v2=12-5 v2=5
v1=v1-v2 #v1=12-5 v1=7
print(v1,v2)

#Q. Write a program to print different vowels present in the given word?
Q10. Write a program to find the number of occurrences of each character present in the given String?

Pavan p-1 a-2
