val=[1,3,6,7,2,87,"Ravi", "ABC"]
result= ("Ravi" not in val)
print(result)
result= ("Ravi" in val)
print(result)

print(5 is not 5)

