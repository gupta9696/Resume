a={1:"Ravi", "2":"Ram"}
a[1]="TYTYT"
a[2]="Shyam"
print(a)

