print("Radhe")

val=int(input("Eneter val"))
v1=1;

for a in range(val, 0, -1):
    #if(a == 1):
     #   print(a, end="")   
   # else: print(a, " X ",end="") 
    print(a, " X ",end="")    
    v1=a*v1
    
print(" = ",v1)