print("Radhe")
m=input("Eneter val")
print("Value of M ", m)
val=int(m)

v2=1
for a in range(1, val+1, 1):
    for b in range(1, a+1, 1):        
        print(v2," ", end="")
        v2+=1
    print()