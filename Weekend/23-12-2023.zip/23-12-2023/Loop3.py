print("Radhe")

val=int(input("Eneter val"))
v1=1;

for a in range(1, val+1, 1):
    print(a,"X")   
    v1=a*v1
    
print("=",v1)