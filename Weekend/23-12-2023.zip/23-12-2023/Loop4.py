print("Radhe")

val=int(input("Eneter val"))

v2=1
for a in range(1, val+1, 1):
    for b in range(1, a+1, 1):        
        print(" * ", end="")
        v2+=1
    print()