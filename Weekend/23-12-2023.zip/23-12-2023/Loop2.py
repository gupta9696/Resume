print("Radhe")

val=int(input("Eneter series"))

for a in range(1, val, 1): 
    if(a % 2 == 0): print("Even :",a)
    else:  print("Odd :",a)