print("Hello There")
name=["Pavan", "Ravi", "Zafer", "Sain"]
val=int(input("Eneter table of any"))
#for a in range(val,(val*10)+1,2): #5 50 +2
 #   print(a)
    
for a in name : 
    if(a == "Ravi"):
        print("helo",a)