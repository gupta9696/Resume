price=int(input("Eneter the Price value"))
discount=int(input("Eneter the Discount value"))

print(price - (price * discount)/100);

