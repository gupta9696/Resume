v1=int(input("Eneter the first value"))
print(v1)
v1=v1+10
v1+=10
print(v1)
